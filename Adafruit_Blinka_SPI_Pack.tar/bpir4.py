# SPDX-FileCopyrightText: 2024 DroZDi
#
# SPDX-License-Identifier: MIT
"""Pin definitions for the Banana Pi BPI-R4."""

from adafruit_blinka.microcontroller.mt7988a import pin

# Pinout reference:
# https://docs.banana-pi.org/en/BPI-R4/GettingStarted_BPI-R4#_gpio_define
#D1 = +3.3V
#D2 = +5V
D3 = pin.GPIO_18  
#D4 = +5V
D5 = pin.GPIO_17
#D6 = GND 
D7 = pin.GPIO_62
D8 = pin.GPIO_59 
#D9 = GND 
D10 = pin.GPIO_58
D11 = pin.GPIO_81
D12 = pin.GPIO_51 
D13 = pin.GPIO_80
#D14 = GND
D15 = pin.GPIO_50
D16 = pin.GPIO_61
#D17 = +3.3V 
D18 = pin.GPIO_60
D19 = pin.GPIO_30
#D20 = GND 
D21 = pin.GPIO_29
D22 = pin.GPIO_53
D23 = pin.GPIO_31
D24 = pin.GPIO_28
#D25 = GND
D26 = pin.GPIO_52  

# UART
UART1_TX = pin.GPIO_59
UART2_TX = pin.GPIO_59
UART1_RX = pin.GPIO_58
UART2_RX = pin.GPIO_58
UART1_TXD = pin.GPIO_81
UART1_RXD = pin.GPIO_80
UART1_RTS = pin.GPIO_61
UART2_RTS = pin.GPIO_61
UART1_CTS = pin.GPIO_60
UART2_CTS = pin.GPIO_60

#Default UART
TX = UART1_TX
RX = UART1_RX
TXD = UART1_TXD
RXD = UART1_RXD

# I2C
I2C_1_SDA = pin.GPIO_18 
I2C_1_SCL = pin.GPIO_17 

# Default I2C
SCL = I2C_1_SCL
SDA = I2C_1_SDA

# SPI
SPI1_MOSI = pin.GPIO_30
SPI1_MISO = pin.GPIO_29
SPI1_CLK = pin.GPIO_31
SPI1_CSB = pin.GPIO_28

# Default SPI
MOSI = SPI1_MOSI 
MISO = SPI1_MISO 
SCLK = SPI1_CLK 
CS0 = SPI1_CSB 

# JTAG
JTAG_JTDO = pin.GPIO_59
JTAG_JTDI = pin.GPIO_58
JTAG_JTCLK = pin.GPIO_61
JTAG_JTMS = pin.GPIO_60 


