#!/bin/bash
#sudo apt-get install qemu-user-static debootstrap binfmt-support
#r2: dev: 0 part: 1/2
#r64: dev: 1 part: 4/5 (maybe needs fix for root in uboot, boot is checked by checkgpt)
#r2pro: dev: 1 part: 2/3
#r3: dev: 0 part: 5/6
board=$1
distro=$2 #buster|bullseye|jammy
kernel="6.10"

LANG=C
ubootconfig=uEnv.txt

case "$board" in
	"bpi-r2")
		mmcdev=0
		mmcbootpart=1
		mmcrootpart=2
		arch="armhf"
		kernel="5.15" #6.0+ does not support internal wifi
		ubootconfigdir=/bananapi/$board/linux/
	;;
	"bpi-r64")
		mmcdev=1
		mmcbootpart=4
		mmcrootpart=5
		arch="arm64"
	;;
	"bpi-r2pro")
		mmcdev=0
		mmcbootpart=2
		mmcrootpart=3
		arch="arm64"
	;;
	"bpi-r3"|"bpi-r4")
		mmcdev=0
		mmcbootpart=5
		mmcrootpart=6
		arch="arm64"
	;;
	*)
		echo "missing/unsupported board $1";exit
	;;
esac

if [[  "$board" == "bpi-r4" ]]; then
	kernel="6.10" #r4 does not have LTS support yet
fi

if [[ -n "$3" ]] && [[ "$3" =~ ^[1-9]\.[0-9]+$ ]];then kernel=$3;fi

PACKAGE_Error=0
PACKAGES=$(dpkg -l | awk '{print $2}')
NEEDED_PKGS="python3 python3-requests parted qemu-user-static debootstrap binfmt-support"
echo "needed: $NEEDED_PKGS"
for package in $NEEDED_PKGS; do
	#TESTPKG=$(dpkg -l |grep "\s${package}")
	TESTPKG=$(echo "$PACKAGES" |grep "^${package}")
	if [[ -z "${TESTPKG}" ]];then echo "please install ${package}";PACKAGE_Error=1;fi
done
if [ ${PACKAGE_Error} == 1 ]; then exit 1; fi


LDEV=`sudo losetup -f`

function cleanup() {
	sudo umount mnt/BPI-BOOT
	sudo umount mnt/BPI-ROOT
	sudo losetup -d $1
}

trap ctrl_c INT
function ctrl_c() {
        echo "** Trapped CTRL-C ($LDEV)"
	cleanup $LDEV
	exit 1
}

echo "create image for ${board} (${arch}) ${distro} ${kernel}"

python3 downloadfiles.py ${board} ${kernel}

ls -lh sourcefiles_${board}.conf
if [[ $? -ne 0 ]];then echo "sourcefiles_$board.conf file missing"; exit 1; fi

. sourcefiles_${board}.conf
echo "image-file: "$imgfile
echo "kernel-file: "$kernelfile
if [[ ! -e ${distro}_${arch}.tar.gz ]];then
	./buildchroot.sh ${arch} ${distro}
else
	echo "packed rootfs already exists"
fi
ls -lh ${imgfile}
if [[ $? -ne 0 ]];then echo "bootloader file missing"; exit 1; fi
ls -lh ${distro}_${arch}.tar.gz
if [[ $? -ne 0 ]];then echo "rootfs file missing"; exit 1; fi

if [[ -z "${kernelfile}" ]];then
	kernel="nokernel"
else
	kernel=$(echo ${kernelfile}|sed -e 's/^.*_\(.*\).tar.gz/\1/')
fi
newimgfile=${board}_${distro}_${kernel}.img.gz

cp $imgfile $newimgfile
echo "unpack imgfile ($newimgfile)..."
gunzip $newimgfile
echo "setting up imgfile to loopdev..."
sudo losetup ${LDEV} ${newimgfile%.*} 1> /dev/null
if [[ $? -ne 0 ]];then echo "losetup ${LDEV} failed (${newimgfile%.*})"; exit 1; fi
echo "mounting loopdev..."
sudo partprobe ${LDEV}
if [[ $? -ne 0 ]];then echo "partprobe failed"; exit 1; fi
mkdir -p mnt/BPI-{B,R}OOT
sudo mount ${LDEV}p${mmcbootpart} mnt/BPI-BOOT
if [[ $? -ne 0 ]];then echo "mounting BPI-BOOT failed"; exit 1; fi
sudo mkdir -p mnt/BPI-BOOT/${ubootconfigdir}
sudo touch mnt/BPI-BOOT/${ubootconfigdir}/${ubootconfig}
sudo mount ${LDEV}p${mmcrootpart} mnt/BPI-ROOT
if [[ $? -ne 0 ]];then echo "mounting BPI-ROOT failed"; exit 1; fi
echo "unpack rootfs to bpi-root loopdev..."
sudo tar -xzf ${distro}_${arch}.tar.gz -C mnt/BPI-ROOT

if [[ -n "${kernelfile}" ]];then
	ls -lh ${kernelfile}
	if [[ $? -ne 0 ]];then echo "kernel file missing"; exit 1; fi
	echo "unpack kernel to bpi-boot loopdev..."
	sudo tar -xzf $kernelfile --strip-components=1 -C mnt/BPI-BOOT BPI-BOOT
	ls -lR mnt/BPI-BOOT
	echo "unpack kernel-modules to bpi-root loopdev..."
	sudo tar -xzf $kernelfile --strip-components=2 -C mnt/BPI-ROOT/lib/. BPI-ROOT/lib/
else
	echo "kernelfile is empty so it will be missing in resulting image..."
fi

if [[ "$board" == "bpi-r2pro" ]];then
	conffile=mnt/BPI-BOOT/extlinux/extlinux.conf
	#mkdir -p $(dirname ${conffile})
	imgname="Image.gz"
	dtbname="bpi-r2pro.dtb"
	ls -la $(dirname ${conffile})
	echo -e "menu title Select the boot mode\n#timeout 1/10s\nTIMEOUT 50\nDEFAULT linux" | sudo tee $conffile
	echo -e "LABEL linux\n	linux $imgname\n	fdt $dtbname\n"\
		"	append earlycon=uart8250,mmio32,0xfe660000 " \
		"console=ttyS2,1500000n8 root=/dev/mmcblk${mmcdev}p${mmcrootpart} rootwait rw " \
		"earlyprintk" | sudo tee -a $conffile
	cat ${conffile}
fi

echo "configure rootfs for ${board}..."

targetdir="mnt/BPI-ROOT"

sudo chroot $targetdir tee "/etc/fstab" > /dev/null <<EOF
# <file system>		<dir>	<type>	<options>		<dump>	<pass>
/dev/mmcblk${mmcdev}p${mmcbootpart}		/boot	vfat	errors=remount-ro	0	1
/dev/mmcblk${mmcdev}p${mmcrootpart}		/	ext4	defaults		0	0
EOF

echo $board | sudo tee $targetdir/etc/hostname

if [[ ${board} != "bpi-r2pro" ]];then
	sudo chroot $targetdir bash -c "apt update; apt install --no-install-recommends -y hostapd iw xz-utils"
fi

sudo cp -r conf/generic/* ${targetdir}/
if [[ -e conf/$board ]];then
	sudo rsync -av --partial --progress --exclude={'bin','lib','sbin'} conf/${board}/. ${targetdir}/

	#fix for copy dir over symlink (rejected by cp)
	for d in bin lib sbin;do
		if [[ -d conf/${board}/$d ]];then
			sudo cp -r conf/${board}/$d/* ${targetdir}/$d/
		fi
	done
fi
sudo chroot $targetdir bash -c "systemctl enable systemd-networkd"

#wifi related commands
if [[ ${board} != "bpi-r2pro" ]];then
	#fix for ConditionFileNotEmpty in existing hostapd service (can also point to ${DAEMON_CONF})
	if [[ ${board} == "bpi-r2" ]];then
		sudo mv $targetdir/etc/hostapd/hostapd_{wlan,ap}0.conf
		sudo sed -i 's/^#\(interface=ap0\)/\1/' $targetdir/etc/hostapd/hostapd_ap0.conf
		cat $targetdir/etc/hostapd/hostapd_ap0.conf
		sudo chroot $targetdir bash -c "ln -fs hostapd_ap0.conf /etc/hostapd/hostapd.conf"
		#unpack wmt-tools
		sudo tar -xzf $kernelfile --strip-components=1 -C $targetdir BPI-ROOT/{etc,usr,system}
		#disable ip setting and dnsmasq (done via systemd-config)
		sed -i "/hostapd started...set IP/,/service dnsmasq restart/d" $targetdir/usr/sbin/wifi.sh
		#add wifi.sh to rc.local (autostart)
		sed -i '/^exit/s/^/\/usr\/sbin\/wifi.sh &\n/' $targetdir/etc/rc.local
	else
		sudo chroot $targetdir bash -c "ln -fs hostapd_wlan0.conf /etc/hostapd/hostapd.conf"
	fi
	#copy firmware
	if [[ ! -d firmware ]];
	then
		./getfirmware.sh
	fi
	echo "copy firmware files"
	sudo cp -r firmware/* ${targetdir}/lib/firmware/

	curl https://git.kernel.org/pub/scm/linux/kernel/git/sforshee/wireless-regdb.git/plain/regulatory.db -o regulatory.db-git
	curl https://git.kernel.org/pub/scm/linux/kernel/git/sforshee/wireless-regdb.git/plain/regulatory.db.p7s -o regulatory.db.p7s-git

	sudo cp -r regulatory.* ${targetdir}/lib/firmware/
    sudo chroot $targetdir bash -c "update-alternatives --install /lib/firmware/regulatory.db regulatory.db /lib/firmware/regulatory.db-git 200 --slave /lib/firmware/regulatory.db.p7s regulatory.db.p7s /lib/firmware/regulatory.db.p7s-git"
    sudo chroot $targetdir bash -c "update-alternatives --set regulatory.db /lib/firmware/regulatory.db-git"

	if [[ ${board} == "bpi-r64" ]];then
		echo "mt7615e" | sudo tee -a ${targetdir}/etc/modules
	fi
fi

#install/start resolved after all is done
sudo chroot $targetdir bash -c "apt install -y systemd-resolved;systemctl enable systemd-resolved"

cleanup ${LDEV}

echo "packing ${newimgfile}"
gzip ${newimgfile%.*}
md5sum ${newimgfile} > ${newimgfile}.md5
echo "install it this way:"
echo "gunzip -c ${newimgfile} | sudo dd bs=1M status=progress conv=notrunc,fsync of=/dev/sdX"

rm $imgfile
